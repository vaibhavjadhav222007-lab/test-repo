#include<stdio.h>
int main()
{
    int x,y,sum=0;
    printf("Enter a number");
    scanf("%d%d, &x,&y")
    while()
}